import requests
from config import TELEGRAM_BOT_TOKEN

def send_telegram_message(chat_id, message, reply_markup=None):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "HTML"
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup

    response = requests.post(url, json=payload)
    print(f"[SEND] To: {chat_id}, Status: {response.status_code}, Response: {response.text}")
    return response.status_code == 200
