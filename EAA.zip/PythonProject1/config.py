OAUTH_PROVIDERS = {
    "google": {
        "client_id": "1053046115923-gs2t273vcqglopitk0mihlg3cpheu8k2.apps.googleusercontent.com",
        "client_secret": "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"
    }
}

SECRET_KEY = 'your-super-secret-key'
FERNET_KEY = "qZqFvGjYH6G_QwIVlY5PjaVXrDMAYA9Yg3gCBXlI3T8="  # Новый Fernet ключ
