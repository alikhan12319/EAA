from telegram_client import send_telegram_message
import os
import random
import smtplib
from datetime import datetime, timedelta
from email.mime.text import MIMEText
import bcrypt
import pyotp
from authlib.integrations.flask_client import OAuth
from flask import Flask, request, session, render_template, redirect, url_for, flash, send_file, jsonify
from flask_sqlalchemy import SQLAlchemy
import glob

import config
from crypto_utils import encrypt_data, decrypt_data

import secrets
import qrcode
from io import BytesIO
from flask import send_file

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

oauth = OAuth(app)
oauth.register(
    name='google',
    client_id=config.OAUTH_PROVIDERS["google"]["client_id"],
    client_secret=config.OAUTH_PROVIDERS["google"]["client_secret"],
    server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
    client_kwargs={'scope': 'openid email profile'}
)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.LargeBinary, nullable=False)
    is_email_verified = db.Column(db.Boolean, default=False)
    backup_code = db.Column(db.String(10), nullable=True)
    failed_attempts = db.Column(db.Integer, default=0)
    is_admin = db.Column(db.Boolean, default=False)
    last_failed_login = db.Column(db.DateTime, nullable=True)  # Добавить в User
    webauthn_credential_id = db.Column(db.Text, nullable=True)
    webauthn_public_key = db.Column(db.Text, nullable=True)
    balance = db.Column(db.Integer, default=1000)
    telegram_chat_id = db.Column(db.String(50), nullable=True)
    is_blocked = db.Column(db.Boolean, default=False)
    blocked_until = db.Column(db.DateTime, nullable=True)

class Log(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), nullable=True)
    ip_address = db.Column(db.String(100), nullable=True)
    status = db.Column(db.String(20), nullable=False)  # success / error
    reason = db.Column(db.String(200), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now)

class TransferLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender = db.Column(db.String(150), nullable=False)
    recipient = db.Column(db.String(150), nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class QRToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(64), unique=True, nullable=False)
    username = db.Column(db.String(150), nullable=True)  # теперь может быть пустым до сканирования
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    used = db.Column(db.Boolean, default=False)
    login_successful = db.Column(db.Boolean, default=False)  # новая колонка

class FaceToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(64), unique=True, nullable=False)
    user_id = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    login_successful = db.Column(db.Boolean, default=False)

class EmailToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    token = db.Column(db.String(64), unique=True, nullable=False)
    username = db.Column(db.String(150), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

with app.app_context():
    db.create_all()

def send_email(to_email, subject, message):
    sender = "alikhan.karim2004@gmail.com"
    password = "hjvbxirqsrcmhper"
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.starttls()
    server.login(sender, password)
    msg = MIMEText(message, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = to_email
    server.sendmail(sender, to_email, msg.as_string())
    server.quit()

def add_log(username, status, reason):
    ip_address = request.remote_addr  # Получаем IP пользователя
    log_entry = Log(username=username, ip_address=ip_address, status=status, reason=reason)
    db.session.add(log_entry)
    db.session.commit()



@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Пароли не совпадают!", "danger")
            return redirect(url_for('register'))

        if User.query.filter_by(username=username).first():
            flash("Такой пользователь уже существует", "danger")
            return redirect(url_for('register'))

        encrypted_email = encrypt_data(email)
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        user = User(username=username, email=encrypted_email, password=hashed_password)
        db.session.add(user)

        token = secrets.token_hex(16)
        email_token = EmailToken(token=token, username=username)
        db.session.add(email_token)
        db.session.commit()

        confirm_url = url_for('verify_email', token=token, _external=True)
        send_email(email, "Подтверждение регистрации",
                   f"Здравствуйте!\n\nПерейдите по ссылке для подтверждения аккаунта:\n{confirm_url}")

        flash("Регистрация завершена. Подтвердите email, перейдя по ссылке в письме.", "info")
        return redirect(url_for('login'))

    return render_template("register.html")

@app.route('/verify_email')
def verify_email():
    token = request.args.get('token')
    record = EmailToken.query.filter_by(token=token).first()

    if not record:
        return "Неверный или просроченный токен подтверждения"

    user = User.query.filter_by(username=record.username).first()
    if user:
        user.is_email_verified = True
        db.session.delete(record)
        db.session.commit()
        flash("Email подтверждён. Теперь вы можете войти.", "success")
        return redirect(url_for('login'))

    return "Пользователь не найден"



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()

        if not user or not bcrypt.checkpw(password.encode(), user.password):
            flash("Неверный логин или пароль", "danger")
            return redirect(url_for('login'))

        if not user.is_email_verified:
            flash("Вы не подтвердили email. Проверьте почту.", "danger")
            return redirect(url_for('login'))

        # Генерация и отправка кода
        code = str(random.randint(100000, 999999))
        user.backup_code = code
        db.session.commit()

        send_email(
            decrypt_data(user.email),
            "Код подтверждения входа",
            f"Ваш код для входа: {code}"
        )

        session['username_pending'] = username
        flash("Код отправлен на вашу почту", "info")
        return redirect(url_for('verify_code'))

    return render_template("login.html")



@app.route('/verify_code', methods=['GET', 'POST'])
def verify_code():
    username = session.get('username_pending')
    if not username:
        flash("Сначала введите логин и пароль", "warning")
        return redirect(url_for('login'))

    user = User.query.filter_by(username=username).first()
    if not user:
        flash("Пользователь не найден", "danger")
        return redirect(url_for('login'))

    if request.method == 'POST':
        code = request.form['code'].strip()
        if code == user.backup_code:
            user.backup_code = None
            db.session.commit()

            session['username'] = user.username
            session['email'] = decrypt_data(user.email)
            session.pop('username_pending', None)
            flash("Вы успешно вошли!", "success")
            return redirect(url_for('profile'))

        flash("Неверный код", "danger")

    return render_template("verify_code.html", username=username)


@app.route('/profile')
def profile():
    if 'username' not in session:
        return redirect(url_for('login'))
    username = session['username']
    user = User.query.filter_by(username=username).first()
    balance = user.balance
    transfers = TransferLog.query.filter_by(sender=username).order_by(TransferLog.timestamp.desc()).limit(3).all()
    total_transfers = TransferLog.query.filter_by(sender=username).count()

    # Подсчет расходов за последние 7 дней
    today = datetime.utcnow()
    days = [(today - timedelta(days=i)).date() for i in reversed(range(7))]
    daily_expenses = []
    for day in days:
        total = db.session.query(db.func.sum(TransferLog.amount)).filter(
            TransferLog.sender == username,
            db.func.date(TransferLog.timestamp) == day
        ).scalar() or 0
        daily_expenses.append(total)

    return render_template(
        "profile.html",
        username=username,
        balance=balance,
        latest_transfers=transfers,
        total_transfers=total_transfers,
        total_weekly_expense=sum(daily_expenses),
        chart_labels=[day.strftime('%a') for day in days],
        chart_data=daily_expenses
    )



@app.route('/profile/settings', methods=['GET', 'POST'])
def profile_settings():
    user = User.query.filter_by(username=session['username']).first()
    if not user:
        flash("Пользователь не найден.", "danger")
        return redirect(url_for('login'))

    if request.method == 'POST':
        form_type = request.form.get('form_type')

        # 📲 Telegram ID
        if form_type == 'telegram':
            telegram_chat_id = request.form.get('telegram_chat_id')
            if telegram_chat_id:
                user.telegram_chat_id = str(telegram_chat_id).strip()
                db.session.commit()
                flash("Telegram Chat ID обновлен", "success")
            else:
                flash("Введите Telegram Chat ID", "warning")

        # 🔒 Смена пароля
        elif form_type == 'password':
            old_password = request.form.get('old_password')
            new_password = request.form.get('new_password')
            if not old_password or not new_password:
                flash("Заполните оба поля для смены пароля", "warning")
                return redirect(url_for('profile_settings'))

            if not bcrypt.checkpw(old_password.encode(), user.password):
                flash("Старый пароль неверный", "danger")
                return redirect(url_for('profile_settings'))

            user.password = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt())
            db.session.commit()
            flash("Пароль успешно изменен", "success")

        # 🔐 Смена PIN
        elif form_type == 'pin':
            old_pin = request.form.get('old_pin')
            new_pin = request.form.get('new_pin')
            if not old_pin or not new_pin:
                flash("Заполните оба поля для смены PIN", "warning")
                return redirect(url_for('profile_settings'))

            if user.pin_code != old_pin:
                flash("Старый PIN неверный", "danger")
                return redirect(url_for('profile_settings'))

            user.pin_code = new_pin
            db.session.commit()
            flash("PIN успешно изменен", "success")

    # 📄 Резервные коды
    backup_codes = [user.backup_code] if user.backup_code else []

    return render_template("profile_settings.html", user=user, backup_codes=backup_codes, username=user.username,
                           email=decrypt_data(user.email))

    return render_template("profile_settings.html", user=user, backup_codes=backup_codes)



@app.route('/generate_backup_codes', methods=['POST'])
def generate_backup_codes():
    if 'username' not in session:
        flash("Пожалуйста, войдите в систему.", "warning")
        return redirect(url_for('login'))

    user = User.query.filter_by(username=session['username']).first()
    new_codes = [str(random.randint(100000, 999999)) for _ in range(5)]
    user.backup_codes = ','.join(new_codes)
    db.session.commit()
    flash("Новые резервные коды успешно сгенерированы!", "success")
    send_email(
        decrypt_data(user.email),
        "Новые резервные коды",
        f"Здравствуйте! Вы запросили новые резервные коды для входа: {', '.join(new_codes)}"
    )

    return redirect(url_for('profile_settings'))



@app.route('/change_password', methods=['POST'])
def change_password():
    user = User.query.filter_by(username=session['username']).first()
    old_password = request.form['old_password']
    new_password = request.form['new_password']

    if bcrypt.checkpw(old_password.encode(), user.password):
        user.password = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt())
        db.session.commit()
        flash("Пароль успешно изменен.", "success")
    else:
        flash("Старый пароль неверный.", "danger")
    send_email(
        decrypt_data(user.email),
        "Ваш пароль был изменен",
        "Здравствуйте! Ваш пароль был успешно изменен. Если это были не вы, срочно свяжитесь с поддержкой."
    )

    return redirect(url_for('profile'))

@app.route('/scan_qr_login')
def scan_qr_login():
    if 'username' not in session:
        flash("Сначала войдите", "warning")
        return redirect(url_for('login'))

    user = User.query.filter_by(username=session['username']).first()
    if not user or not user.telegram_chat_id:
        flash("Telegram ID не найден. Сначала свяжите в настройках профиля.", "danger")
        return redirect(url_for('profile_settings'))

    return render_template("scan_qr_login.html", tg_id=user.telegram_chat_id)


@app.route('/change_pin', methods=['POST'])
def change_pin():
    if 'username' not in session:
        flash("Пожалуйста, войдите в систему.", "warning")
        return redirect(url_for('login'))

    user = User.query.filter_by(username=session['username']).first()
    old_pin = request.form['old_pin']
    new_pin = request.form['new_pin']

    if user.pin_code == str(old_pin):  # сравнение как строки
        user.pin_code = str(new_pin)  # сохраняем как строку
        db.session.commit()
        flash("PIN успешно изменен.", "success")
    else:
        flash("Неверный старый PIN.", "danger")

    return redirect(url_for('profile'))


@app.route('/admin')
def admin_panel():
    if session['username'] != 'admin':
        return redirect(url_for('login'))
    users = User.query.all()
    return render_template('admin_panel.html', users=users)

@app.route('/admin/reset_backup/<int:user_id>')
def admin_reset_backup(user_id):
    user = User.query.get(user_id)
    new_codes = [str(random.randint(100000, 999999)) for _ in range(5)]
    user.backup_codes = ','.join(new_codes)
    db.session.commit()
    return redirect(url_for('admin_panel'))

@app.route('/admin/block_user/<int:user_id>')
def admin_block_user(user_id):
    user = User.query.get(user_id)
    user.failed_attempts = 3
    db.session.commit()
    return redirect(url_for('admin_panel'))

@app.route('/admin/unblock_user/<int:user_id>')
def admin_unblock_user(user_id):
    user = User.query.get(user_id)
    user.failed_attempts = 0  # Снять блокировку
    db.session.commit()
    flash("Пользователь разблокирован.", "success")
    return redirect(url_for('admin_panel'))


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/login/google')
def login_google():
    redirect_uri = url_for('authorize_google', _external=True)
    nonce = os.urandom(16).hex()
    session['nonce'] = nonce
    return oauth.google.authorize_redirect(redirect_uri, nonce=nonce)

@app.route('/authorize/google')
def authorize_google():
    token = oauth.google.authorize_access_token()
    user_info = oauth.google.parse_id_token(token, nonce=session.pop('nonce', None))

    # Проверяем, содержит ли user_info необходимую информацию
    email = user_info.get('email')
    if not email:
        flash("Не удалось получить email из профиля Google", "danger")
        return redirect(url_for('login'))

    # Проверяем, есть ли пользователь в базе данных
    user = User.query.filter_by(email=email).first()
    if not user:
        # Если пользователя нет, создаем нового
        username = email.split('@')[0]
        user = User(
            username=username,
            email=email,
            password=b'',
        )
        db.session.add(user)
        db.session.commit()

    # Сохраняем данные о входе в сессию
    session['username'] = user.username
    session['email'] = user.email

    # Отправляем пользователя в профиль
    flash("Вы успешно вошли через Google!", "success")
    return redirect(url_for('profile'))



@app.route('/admin/logs')
def admin_logs():
    user = User.query.filter_by(username=session['username']).first()
    if not user or not user.is_admin:
        flash('Доступ запрещен!', 'danger')
        return redirect(url_for('login'))
    logs = Log.query.order_by(Log.timestamp.desc()).all()
    return render_template('admin_logs.html', logs=logs)


@app.route('/transfer')
def transerPage():
    if 'username' not in session:
        return redirect(url_for('login'))

    current_user = session['username']
    users = User.query.all()
    return render_template('transfer.html', users=users, current_user=current_user)

@app.route('/transfer_money', methods=['POST'])
def transfer_money():
    if 'username' not in session:
        flash("Сначала войдите в аккаунт.", "warning")
        return redirect(url_for('login'))

    sender = User.query.filter_by(username=session['username']).first()
    recipient_username = request.form['recipient']
    amount = int(request.form['amount'])

    if sender.balance < amount:
        flash("Недостаточно средств.", "danger")
        return redirect(url_for('transerPage'))

    recipient = User.query.filter_by(username=recipient_username).first()
    if not recipient:
        flash("Получатель не найден.", "danger")
        return redirect(url_for('transerPage'))

    sender.balance -= amount
    recipient.balance += amount
    db.session.commit()

    log = TransferLog(sender=sender.username, recipient=recipient.username, amount=amount)
    db.session.add(log)
    db.session.commit()

    flash(f"Успешно переведено {amount} пользователю {recipient.username}.", "success")

    # сообщение для получателя
    if recipient.telegram_chat_id:
        message = (
            f"📥 <b>Вам поступил перевод</b>\n"
            f"👤 От: {sender.username}\n"
            f"💰 Сумма: {amount} ₸\n"
            f"💼 Ваш новый баланс: {recipient.balance} ₸\n"
            f"🕒 Время: {datetime.now().strftime('%d.%m.%Y %H:%M')}\n"
        )
        verify_url = url_for('report_transaction', sender=sender.username, amount=amount, _external=True)
        reply_markup = {
            "inline_keyboard": [[
                {"text": "Это не я ❌", "url": verify_url}
            ]]
        }
        send_telegram_message(recipient.telegram_chat_id, message, reply_markup)

    # сообщение для отправителя
    if sender.telegram_chat_id:
        sender_message = (
            f"📤 Вы отправили перевод\n"
            f"👤 Кому: {recipient.username}\n"
            f"💰 Сумма: {amount} ₸\n"
            f"💼 Ваш новый баланс: {sender.balance} ₸\n"
            f"🕒 Время: {datetime.now().strftime('%d.%m.%Y %H:%M')}\n"
        )
        verify_url = url_for('report_transaction', sender=sender.username, amount=amount, _external=True)
        reply_markup = {
            "inline_keyboard": [[
                {"text": "Это не я ❌", "url": verify_url}
            ]]
        }
        send_telegram_message(sender.telegram_chat_id, sender_message)

    return redirect(url_for('transerPage'))

@app.route('/transfer_logs')
def transfer_logs():
    if 'username' not in session:
        return redirect(url_for('login'))
    logs = TransferLog.query.order_by(TransferLog.timestamp.desc()).all()
    return render_template('transfer_log.html', logs=logs)

@app.route('/report_transaction')
def report_transaction():
    username = request.args.get('sender')
    user = User.query.filter_by(username=username).first()
    if user:
        user.is_blocked = True
        user.blocked_until = datetime.now() + timedelta(minutes=5)
        db.session.commit()
        return "Пользователь временно заблокирован и будет проверен админом."
    return "Пользователь не найден."

@app.route('/qr_login')
def show_qr_login():
    return render_template("qr_login.html")

@app.route('/login/qr')
def login_qr():
    token = request.args.get('token')
    if not token:
        return "Token is required", 400

    qr_url = url_for('confirm_qr', token=token, _external=True)
    img = qrcode.make(qr_url)
    buffer = BytesIO()
    img.save(buffer, 'PNG')
    buffer.seek(0)

    return send_file(buffer, mimetype='image/png')


@app.route('/poll_login_status')
def poll_login_status():
    token = request.args.get('token')
    qr = QRToken.query.filter_by(token=token).first()

    if qr and qr.login_successful:
        return jsonify({"logged_in": True})

    return jsonify({"logged_in": False})

@app.route('/poll_face_status')
def poll_face_status():
    token = request.args.get('token')
    face_token = FaceToken.query.filter_by(token=token).first()

    if face_token and face_token.login_successful:
        user = User.query.filter_by(id=face_token.user_id).first()
        if user:
            session['username'] = user.username
            session['email'] = decrypt_data(user.email)
            return jsonify({"logged_in": True})
    return jsonify({"logged_in": False}), 200


@app.route('/complete_qr_login')
def complete_qr_login():
    token = request.args.get('token')
    qr = QRToken.query.filter_by(token=token).first()

    if not qr or not qr.login_successful:
        flash("Невозможно завершить вход по QR-коду", "danger")
        return redirect(url_for('login'))

    user = User.query.filter_by(username=qr.username).first()
    if not user:
        flash("Пользователь не найден", "danger")
        return redirect(url_for('login'))

    # ✅ Установим сессию на ПК
    session['username'] = user.username
    session['email'] = decrypt_data(user.email)

    # ✅ Помечаем QR как использованный
    qr.used = True
    db.session.commit()

    flash("Вы успешно вошли через QR!", "success")
    return redirect(url_for('profile'))


@app.route('/confirm_qr')
def confirm_qr():
    token = request.args.get('token')
    tg_id = str(request.args.get('tg_id')).strip()

    print(f"DEBUG: token={token}, tg_id={tg_id}")

    qr = QRToken.query.filter_by(token=token, used=False).first()
    if not qr:
        return "QR не найден или уже использован", 404

    user = User.query.filter_by(telegram_chat_id=tg_id).first()
    if not user:
        print("DEBUG: Пользователи с telegram_chat_id:")
        for u in User.query.all():
            print(f"{u.username} — {u.telegram_chat_id} (type: {type(u.telegram_chat_id)})")
        return f"❌ Пользователь с Telegram ID {tg_id} не найден", 404

    qr.username = user.username
    qr.login_successful = True
    db.session.commit()
    return "✅ Вход подтверждён"

@app.route('/get_qr_token')
def get_qr_token():
    token = secrets.token_hex(16)
    qr_entry = QRToken(token=token, username=None)  # пока не знаем кто
    db.session.add(qr_entry)
    db.session.commit()
    return jsonify({"token": token})

@app.route('/face_register', methods=['GET', 'POST'])
def face_register():
    if 'username' not in session:
        flash("Сначала войдите в аккаунт", "warning")
        return redirect(url_for('login'))

    user = User.query.filter_by(username=session['username']).first()
    if not user:
        flash("Пользователь не найден", "danger")
        return redirect(url_for('login'))

    user.face_id = user.id
    db.session.commit()

    face_dir = f"TrainingImage/{user.id}"
    if os.path.exists(face_dir):
        for f in glob.glob(f"{face_dir}/*.jpg"):
            os.remove(f)
    else:
        os.makedirs(face_dir)

    os.system(f"python Readface.py {user.username} {user.id}")
    os.system("python Train.py")

    flash("Биометрические данные зарегистрированы. Теперь вы можете использовать вход по лицу.", "success")
    return redirect(url_for('profile'))

@app.route('/face_login')
def face_login():
    token = secrets.token_hex(16)
    token_entry = FaceToken(token=token)
    db.session.add(token_entry)
    db.session.commit()
    return render_template("face_login.html", token=token)

@app.route('/start_face_detection')
def start_face_detection():
    token = request.args.get('token')
    if not token:
        return "❌ Токен не передан", 400
    os.system(f"python Detectface.py {token}")
    return "⏳ Распознавание завершено. Вернитесь в окно входа."



@app.route('/confirm_face_login')
def confirm_face_login():
    token = request.args.get('token')
    face_id = request.args.get('face_id')

    if not token or not face_id:
        return "Ошибка: токен или face_id не передан", 400

    user = User.query.filter_by(id=face_id).first()
    if not user:
        return "Пользователь не найден", 404

    token_entry = FaceToken.query.filter_by(token=token).first()
    if not token_entry:
        return "Токен не найден", 404

    token_entry.user_id = user.id
    token_entry.login_successful = True
    db.session.commit()

    return "✅ Успешный вход по лицу. Перейдите в браузер."

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
