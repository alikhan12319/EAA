import cv2
import os
import sys
import csv

# Используем безопасный встроенный путь к классификатору
face_detector = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
cam = cv2.VideoCapture(0)

# Получаем имя и ID из аргументов командной строки
name = sys.argv[1] if len(sys.argv) > 1 else "Unknown"
Id = sys.argv[2] if len(sys.argv) > 2 else "0"

sampleNum = 0

# Создаём папку для хранения изображений, если не существует
if not os.path.exists('TrainingImage'):
    os.makedirs('TrainingImage')

while True:
    ret, img = cam.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        sampleNum += 1
        cv2.imwrite(f"TrainingImage/{name}.{Id}.{sampleNum}.jpg", gray[y:y+h, x:x+w])
        cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)
        cv2.putText(img, f"{name} {sampleNum}", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2)
        cv2.imshow('Face Register', img)

    if cv2.waitKey(100) & 0xFF == ord('q'):
        break
    elif sampleNum >= 60:
        break

cam.release()
cv2.destroyAllWindows()

# Перезаписываем имя пользователя с тем же Id (если есть)
rows = []
profile_exists = False

if os.path.exists('Profile.csv'):
    with open('Profile.csv', 'r', newline='') as csvFile:
        reader = csv.reader(csvFile)
        for row in reader:
            if row[0] == Id:
                row[1] = name
                profile_exists = True
            rows.append(row)

with open('Profile.csv', 'w', newline='') as csvFile:
    writer = csv.writer(csvFile)
    if not profile_exists:
        rows.append([Id, name])
    writer.writerows(rows)

exit(0)
