import time
import requests
import cv2
import numpy as np
from pyzbar.pyzbar import decode
from io import BytesIO
from datetime import datetime, timedelta
from telegram_client import send_telegram_message
from app import app, db, User, QRToken
from config import TELEGRAM_BOT_TOKEN

BASE_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"
FILE_URL = f"https://api.telegram.org/file/bot{TELEGRAM_BOT_TOKEN}"

def get_updates(offset=None):
    url = f"{BASE_URL}/getUpdates"
    params = {"timeout": 30, "offset": offset}
    response = requests.get(url, params=params)
    return response.json().get("result", [])

def handle_connect_command(chat_id, username):
    with app.app_context():
        user = User.query.filter_by(username=username).first()
        if not user:
            send_telegram_message(chat_id, f"❌ Пользователь '{username}' не найден.")
            return
        user.telegram_chat_id = str(chat_id)
        db.session.commit()
        send_telegram_message(chat_id, f"✅ Telegram ID привязан к '{username}'")

def handle_token_scan(chat_id, token):
    with app.app_context():
        user = User.query.filter_by(telegram_chat_id=str(chat_id)).first()
        if not user:
            send_telegram_message(chat_id, "❌ Telegram не привязан к вашему аккаунту. Используйте /connect <username>")
            return
        qr = QRToken.query.filter_by(token=token, used=False, login_successful=False).first()
        if not qr or datetime.utcnow() - qr.created_at > timedelta(minutes=5):
            send_telegram_message(chat_id, "⏱️ QR-код просрочен или не найден. Обновите страницу на компьютере.")
            return
        qr.username = user.username
        qr.login_successful = True
        db.session.commit()
        send_telegram_message(chat_id, f"🔓 Успешный вход как {user.username}. Можете продолжить на компьютере.")

def handle_scan_command(chat_id):
    send_telegram_message(chat_id, "📷 Пожалуйста, отправьте изображение с QR-кодом.")

def handle_photo(photo_id, chat_id):
    # Получаем файл
    file_info = requests.get(f"{BASE_URL}/getFile?file_id={photo_id}").json()
    file_path = file_info["result"]["file_path"]
    file_url = f"{FILE_URL}/{file_path}"

    # Загружаем изображение
    image_data = requests.get(file_url).content
    img = cv2.imdecode(np.frombuffer(image_data, np.uint8), cv2.IMREAD_COLOR)

    decoded = decode(img)
    if not decoded:
        send_telegram_message(chat_id, "❌ Не удалось распознать QR-код.")
        return

    qr_data = decoded[0].data.decode("utf-8")
    if "token=" not in qr_data:
        send_telegram_message(chat_id, "❌ QR не содержит токен.")
        return

    token = qr_data.split("token=")[-1].split("&")[0]
    handle_token_scan(chat_id, token)

def run_bot():
    print("🤖 Telegram-бот запущен")
    last_update_id = None

    while True:
        updates = get_updates(offset=last_update_id)
        for update in updates:
            if "message" not in update:
                continue
            message = update["message"]
            chat_id = message["chat"]["id"]

            if "text" in message:
                text = message["text"].strip().lower()

                if text.startswith("/connect"):
                    parts = text.split()
                    if len(parts) == 2:
                        handle_connect_command(chat_id, parts[1])
                    else:
                        send_telegram_message(chat_id, "Использование: /connect <username>")
                elif text.startswith("token="):
                    token = text.split("=", 1)[1].strip()
                    handle_token_scan(chat_id, token)
                elif text == "/scan":
                    handle_scan_command(chat_id)

            elif "photo" in message:
                photo = message["photo"][-1]  # самое крупное фото
                handle_photo(photo["file_id"], chat_id)

            last_update_id = update["update_id"] + 1

        time.sleep(2)

if __name__ == "__main__":
    run_bot()
