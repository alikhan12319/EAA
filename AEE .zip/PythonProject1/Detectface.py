import cv2
print("✅ cv2 loaded from:", cv2.__file__)
print("✅ cv2.face available:", hasattr(cv2, "face"))


import numpy as np
import os
import csv
import requests
import time
import sys

# ✅ Получаем токен из аргумента
token = sys.argv[1] if len(sys.argv) > 1 else None
if not token:
    print("❌ Токен не передан. Завершение.")
    exit(1)

print("⌛ Запуск камеры. Смотрите прямо на экран...")
time.sleep(2)

# ✅ Проверка модели
model_path = "TrainData/Trainner.yml"
if not os.path.exists(model_path):
    print("❌ Модель не найдена. Обучите её через /face_register")
    exit(1)

try:
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(model_path)
except cv2.error as e:
    print("❌ Ошибка загрузки модели:", e)
    exit(1)

# ✅ Классификатор лица
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
cam = cv2.VideoCapture(0)
font = cv2.FONT_HERSHEY_SIMPLEX

if not cam.isOpened():
    print("Камера не найдена")
    exit()

# ✅ Загружаем имена пользователей
names = ['None']
with open('Profile.csv', 'r') as file:
    reader = csv.reader(file)
    for row in reader:
        names.append(row[1])

recognized_id = None
start_time = time.time()
timeout = 10  # секунд

while True:
    ret, img = cam.read()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.2, 5)

    for (x, y, w, h) in faces:
        id, confidence = recognizer.predict(gray[y:y + h, x:x + w])
        print(f"→ Confidence: {confidence:.2f}, ID: {id}")
        if confidence < 50:
            recognized_id = id
            name = names[id] if id < len(names) else f"User {id}"
            confidence_text = f"{round(100 - confidence)}%"
            cv2.putText(img, name, (x + 5, y - 5), font, 1, (0, 255, 0), 2)
        else:
            name = "Unknown"
            confidence_text = f"{round(100 - confidence)}%"

        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
        cv2.putText(img, str(name), (x + 5, y - 5), font, 1, (255, 255, 255), 2)
        cv2.putText(img, str(confidence_text), (x + 5, y + h - 5), font, 1, (255, 255, 0), 1)

    cv2.imshow('Face', img)

    if recognized_id is not None:
        try:
            response = requests.get(f"http://127.0.0.1:5000/confirm_face_login?token={token}&face_id={recognized_id}")
            print(response.text)
        except Exception as e:
            print("Ошибка при отправке запроса:", e)
        break

    if time.time() - start_time > timeout:
        print("⏳ Время ожидания истекло. Лицо не распознано.")
        break

    if cv2.waitKey(10) & 0xFF == ord('q'):
        break

cam.release()
cv2.destroyAllWindows()

if recognized_id is not None:
    exit(0)
else:
    time.sleep(2)
    exit(1)
