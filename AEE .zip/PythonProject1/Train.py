import cv2
import os
import numpy as np
from PIL import Image

def getImagesAndLabels(path):
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    faces = []
    Ids = []

    for imagePath in imagePaths:
        try:
            pilImage = Image.open(imagePath).convert('L')
            imageNp = np.array(pilImage, 'uint8')
            Id = int(os.path.split(imagePath)[-1].split(".")[1])
            faces.append(imageNp)
            Ids.append(Id)
        except Exception as e:
            print(f"❌ Ошибка обработки изображения {imagePath}: {e}")
            continue

    return faces, Ids

def TrainImages():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    harcascadePath = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
    detector = cv2.CascadeClassifier(harcascadePath)

    data_path = "TrainingImage"
    if not os.path.exists(data_path):
        print("❌ Папка с изображениями не найдена.")
        return

    faces, Ids = getImagesAndLabels(data_path)

    if len(faces) == 0 or len(Ids) == 0:
        print("❌ Недостаточно данных для обучения.")
        return

    recognizer.train(faces, np.array(Ids))

    if not os.path.exists("TrainData"):
        os.makedirs("TrainData")

    recognizer.save("TrainData/Trainner.yml")
    print("✅ Модель обучена и сохранена в 'TrainData/Trainner.yml'")

TrainImages()
